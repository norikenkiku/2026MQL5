//+------------------------------------------------------------------+
//|                                               mekiki_HLbands.mq5 |
//|                        Copyright 2019, MetaQuotes Software Corp. |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright   "2009-2017, mekiki.me"
#property link        "https://fx.mekiki.me"
#property description "HL Bands"
#include <mekiki/LibMQL4.mqh>

//----
#property indicator_separate_window
#property indicator_buffers 1
#property indicator_plots   1

#property indicator_type1   DRAW_LINE
#property indicator_color1  Aqua

// input para
input int HLPeriod = 4;

// work
double NowPrice=0;
double BufHigh[];


int OnInit()
  {
   
   SetIndexBuffer(0,BufHigh);


   ArraySetAsSeries(BufHigh, true);


   return(INIT_SUCCEEDED);
  }
//-- 
int OnCalculate(  const int rates_total,
                  const int prev_calculated,
                  const datetime &time[],
                  const double &open[],
                  const double &high[],
                  const double &low[],
                  const double &close[],
                  const long &tick_volume[],
                  const long &volume[],
                  const int &spread[])
{
   ArraySetAsSeries(high, true);
   ArraySetAsSeries(low, true);  
   int limit = rates_total - prev_calculated;
   limit =MathMin(limit, rates_total-HLPeriod); 
         
   for(int i=0; i<limit; i++)
   {
      BufHigh[i] = iClose(NULL, 0, i)-high[ArrayMaximum(high, i+1, HLPeriod)];

   }
   
   return(rates_total-1);

}
