//+------------------------------------------------------------------+
//|                                               mekiki_HLbands.mq5 |
//|                        Copyright 2019, MetaQuotes Software Corp. |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright   "2009-2017, mekiki.me"
#property link        "https://fx.mekiki.me"
#property description "HL Bands"
#include <mekiki/LibMQL4.mqh>

//----
#property indicator_chart_window
#property indicator_buffers 3
#property indicator_plots   3
#property indicator_type1   DRAW_LINE
#property indicator_color1  Aqua
#property indicator_type2   DRAW_LINE
#property indicator_color2  White
#property indicator_type3   DRAW_LINE
#property indicator_color3  Orange
//#property indicator_label1  "Bands upper"
//#property indicator_label2  "Bands main"
//#property indicator_label3  "Bands lower"
// input para
input int HLPeriod = 20;
input int PriceField =0;
// work
int ExBandPeriod, ExPriceField;
int           ExPlotBegin=0;

double BufHigh[];
double BufMed[];
double BufLow[];

int OnInit()
  {
   if(HLPeriod<2){
      ExBandPeriod=20;
      printf("Incorrect value for input variable BandPeriod=%d. Indicator will use value=%d for calculations.",ExBandPeriod,ExBandPeriod);
   }
   else{ 
      ExBandPeriod = HLPeriod;
   }
   if(PriceField !=0 && PriceField !=1){
      ExPriceField = 0;
      printf("Incorrect value for input variable PriceField=%d. Indicator will use value=%d for calculations.",PriceField,ExPriceField);
   }
   else{ 
      ExPriceField = PriceField;
   }   
   
   SetIndexBuffer(0,BufHigh);
   SetIndexBuffer(1,BufMed);
   SetIndexBuffer(2,BufLow);

   ArraySetAsSeries(BufHigh, true);
   ArraySetAsSeries(BufMed, true);
   ArraySetAsSeries(BufLow, true);

         
//   IndicatorSetString(INDICATOR_SHORTNAME,"HL Bands");
////
//////--- indexes draw begin settings
//   ExPlotBegin=ExBandPeriod-1;
//   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,ExBandPeriod);
//   PlotIndexSetInteger(1,PLOT_DRAW_BEGIN,ExBandPeriod);
//   PlotIndexSetInteger(2,PLOT_DRAW_BEGIN,ExBandPeriod);         
////
//////--- number of digits of indicator value
//   IndicatorSetInteger(INDICATOR_DIGITS,_Digits+1);

   return(INIT_SUCCEEDED);
  }
//-- 
int OnCalculate(  const int rates_total,
                  const int prev_calculated,
                  const datetime &time[],
                  const double &open[],
                  const double &high[],
                  const double &low[],
                  const double &close[],
                  const long &tick_volume[],
                  const long &volume[],
                  const int &spread[])
{
   ArraySetAsSeries(high, true);
   ArraySetAsSeries(low, true);  
   int limit = rates_total - prev_calculated;
   limit =MathMin(limit, rates_total-ExBandPeriod);
         
   for(int i=0; i<limit; i++)
   {

      BufHigh[i] = high[ArrayMaximum(high, i, ExBandPeriod)];
      BufLow[i] = low[ArrayMinimum(low, i, ExBandPeriod)];
      BufMed[i] = (BufHigh[i] + BufLow[i])/ 2;
      
      if(BufHigh[i]==EMPTY_VALUE || BufLow[i]==EMPTY_VALUE) return 0;

   }
   
   return(rates_total-1);

}
