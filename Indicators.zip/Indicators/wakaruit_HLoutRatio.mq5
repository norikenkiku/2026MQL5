//+------------------------------------------------------------------+
//|                                               mekiki_HLbands.mq5 |
//|                        Copyright 2019, MetaQuotes Software Corp. |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright   "2009-2017, mekiki.me"
#property link        "https://fx.mekiki.me"
#property description "HL Bands"
#include <mekiki/LibMQL4.mqh>

//----
#property indicator_separate_window
#property indicator_buffers 2
#property indicator_plots   2
#property indicator_type1   DRAW_LINE
#property indicator_color1  Aqua
#property indicator_type2   DRAW_LINE
#property indicator_color2  White

// input para
input int HLPeriod = 3;
input int PriceField =0;

// work
int ExHLPeriod;

double BufHigh[];
double BufLow[];

int OnInit()
  {
   if(HLPeriod<2){
      ExHLPeriod=20;
      printf("Incorrect value for input variable BandPeriod=%d. Indicator will use value=%d for calculations.",ExHLPeriod,ExHLPeriod);
   }
   else{ 
      ExHLPeriod = HLPeriod;
   }

   SetIndexBuffer(0,BufHigh);
   SetIndexBuffer(1,BufLow);

   ArraySetAsSeries(BufHigh, true);
   ArraySetAsSeries(BufLow, true);

   return(INIT_SUCCEEDED);
  }
//-- 
int OnCalculate(  const int rates_total,
                  const int prev_calculated,
                  const datetime &time[],
                  const double &open[],
                  const double &high[],
                  const double &low[],
                  const double &close[],
                  const long &tick_volume[],
                  const long &volume[],
                  const int &spread[])
{
   ArraySetAsSeries(high, true);
   ArraySetAsSeries(low, true);
   ArraySetAsSeries(close, true);
     
   int limit = rates_total - prev_calculated;
   limit =MathMin(limit, rates_total-ExHLPeriod);
   
   double TermHighi=0;
   double TermLowi=0;
            
   for(int i=0; i<limit; i++)
   {

      TermHighi = high[ArrayMaximum(high, i+1, ExHLPeriod)];
      TermLowi = low[ArrayMinimum(low, i+1, ExHLPeriod)];
      
      if((TermHighi - TermLowi) == 0) return 0;
      
      if(TermHighi < close[i])
      {
         BufHigh[i] = (close[i] - TermHighi)/(TermHighi - TermLowi);
      }
      else
      {
         BufHigh[i] = 0;
      }
      
      if(TermLowi > close[i])
      {
         BufLow[i] = (close[i] - TermLowi)/(TermHighi - TermLowi);
      }
      else
      {
         BufLow[i] = 0;
      }      


   }
   
   return(rates_total-1);

}
