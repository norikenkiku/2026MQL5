﻿//+------------------------------------------------------------------+
//|                                Quantum_Interference_Oscillator.mq5|
//|                                     Created by Gemini & You      |
//+------------------------------------------------------------------+
#property copyright "Created by Gemini & You"
#property version   "1.10"
#property description "Quantifies the interference of Bollinger Band Z-scores between two selectable timeframes."

// サブウィンドウに表示し、バッファを1つ使用する設定
#property indicator_separate_window
#property indicator_buffers 1
#property indicator_plots   1

// ヒストグラム（棒グラフ）の描画設定
#property indicator_label1  "Interference (Wave Product)"
#property indicator_type1   DRAW_HISTOGRAM
#property indicator_color1  clrDodgerBlue
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2

// 0ラインの表示
#property indicator_level1  0.0
#property indicator_levelcolor clrGray
#property indicator_levelstyle STYLE_DOT

//--- 入力パラメータ（設定画面で自由に変更可能）
input ENUM_TIMEFRAMES InpTimeFrame1 = PERIOD_M5; // タイムフレーム 1 (小さな波)
input ENUM_TIMEFRAMES InpTimeFrame2 = PERIOD_H1; // タイムフレーム 2 (大きな波)
input int InpPeriod = 20;                        // ボリンジャーバンド期間 (Default: 20)

//--- 計算用バッファ
double InterferenceBuffer[];

//--- インジケーターのハンドル（設計図）を格納する変数
int handle_ma_tf1, handle_std_tf1;
int handle_ma_tf2, handle_std_tf2;

//+------------------------------------------------------------------+
//| 初期化関数 (OnInit)                                              |
//+------------------------------------------------------------------+
int OnInit()
  {
   // バッファの紐づけ
   SetIndexBuffer(0, InterferenceBuffer, INDICATOR_DATA);
   
   // サブウィンドウの左上に表示される名前を自動生成（例: Quantum Interference (M5 & H1, 20)）
   string name = "Quantum Interference (" + EnumToString(InpTimeFrame1) + " & " + EnumToString(InpTimeFrame2) + ", " + IntegerToString(InpPeriod) + ")";
   IndicatorSetString(INDICATOR_SHORTNAME, name);

   // タイムフレーム1の移動平均線と標準偏差のハンドルを取得
   handle_ma_tf1 = iMA(_Symbol, InpTimeFrame1, InpPeriod, 0, MODE_SMA, PRICE_CLOSE);
   handle_std_tf1 = iStdDev(_Symbol, InpTimeFrame1, InpPeriod, 0, MODE_SMA, PRICE_CLOSE);
   
   // タイムフレーム2の移動平均線と標準偏差のハンドルを取得
   handle_ma_tf2 = iMA(_Symbol, InpTimeFrame2, InpPeriod, 0, MODE_SMA, PRICE_CLOSE);
   handle_std_tf2 = iStdDev(_Symbol, InpTimeFrame2, InpPeriod, 0, MODE_SMA, PRICE_CLOSE);

   // エラーチェック
   if(handle_ma_tf1 == INVALID_HANDLE || handle_std_tf1 == INVALID_HANDLE ||
      handle_ma_tf2 == INVALID_HANDLE || handle_std_tf2 == INVALID_HANDLE)
     {
      Print("エラー：インジケーターのハンドル作成に失敗しました。");
      return(INIT_FAILED);
     }

   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| 毎ティックの計算処理 (OnCalculate)                               |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   // 計算の開始位置を設定（過去のバーを再計算しないための処理）
   int limit = prev_calculated == 0 ? 0 : prev_calculated - 1;

   // 各バーに対してループ処理
   for(int i = limit; i < rates_total; i++)
     {
      datetime t = time[i]; // 現在計算しているバーの時間

      // 一時的に値を格納する配列
      double ma_tf1[1], std_tf1[1], close_tf1[1];
      double ma_tf2[1], std_tf2[1], close_tf2[1];

      // 指定した時間のデータを両方のタイムフレームから取得
      if(CopyBuffer(handle_ma_tf1, 0, t, 1, ma_tf1) <= 0 ||
         CopyBuffer(handle_std_tf1, 0, t, 1, std_tf1) <= 0 ||
         CopyClose(_Symbol, InpTimeFrame1, t, 1, close_tf1) <= 0 || // TF1の終値も明示的に取得
         CopyBuffer(handle_ma_tf2, 0, t, 1, ma_tf2) <= 0 ||
         CopyBuffer(handle_std_tf2, 0, t, 1, std_tf2) <= 0 ||
         CopyClose(_Symbol, InpTimeFrame2, t, 1, close_tf2) <= 0)   // TF2の終値
        {
         // 過去データの読み込みが完了していない場合の待機処理
         if(rates_total - i < 2000) 
            return 0; 
         
         // データが存在しないほど過去の場合は0を入れてスキップ
         InterferenceBuffer[i] = 0;
         continue;
        }

      // タイムフレーム1の波（Zスコア）を計算
      double z_tf1 = 0;
      if(std_tf1[0] > 0) 
         z_tf1 = (close_tf1[0] - ma_tf1[0]) / std_tf1[0];

      // タイムフレーム2の波（Zスコア）を計算
      double z_tf2 = 0;
      if(std_tf2[0] > 0) 
         z_tf2 = (close_tf2[0] - ma_tf2[0]) / std_tf2[0];

      // 干渉度（2つの波の積）を計算し、バッファに格納
      InterferenceBuffer[i] = z_tf1 * z_tf2;
     }

   return(rates_total);
  }
//+------------------------------------------------------------------+