﻿//+------------------------------------------------------------------+
//|                                Quantum_Interference_Oscillator.mq5|
//|                                     Created by Gemini & You      |
//+------------------------------------------------------------------+
#property copyright "Created by Gemini & You"
#property version   "1.00"
#property description "Quantifies the interference of Bollinger Band Z-scores between M5 and H1."

// サブウィンドウに表示し、バッファを1つ使用する設定
#property indicator_separate_window
#property indicator_buffers 1
#property indicator_plots   1

// ヒストグラム（棒グラフ）の描画設定
#property indicator_label1  "Interference (Wave Product)"
#property indicator_type1   DRAW_HISTOGRAM
#property indicator_color1  clrDodgerBlue
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2

// 0ラインの表示
#property indicator_level1  0.0
#property indicator_levelcolor clrGray
#property indicator_levelstyle STYLE_DOT

//--- 入力パラメータ（ボリンジャーバンドの期間）
input int InpPeriod = 20; // ボリンジャーバンド期間 (Default: 20)

//--- 計算用バッファ
double InterferenceBuffer[];

//--- インジケーターのハンドル（設計図）を格納する変数
int handle_ma_m5, handle_std_m5;
int handle_ma_h1, handle_std_h1;

//+------------------------------------------------------------------+
//| 初期化関数 (OnInit)                                              |
//+------------------------------------------------------------------+
int OnInit()
  {
   // バッファの紐づけ
   SetIndexBuffer(0, InterferenceBuffer, INDICATOR_DATA);
   IndicatorSetString(INDICATOR_SHORTNAME, "Quantum Interference (" + IntegerToString(InpPeriod) + ")");

   // 5分足（M5）の移動平均線と標準偏差のハンドルを取得
   handle_ma_m5 = iMA(_Symbol, PERIOD_M5, InpPeriod, 0, MODE_SMA, PRICE_CLOSE);
   handle_std_m5 = iStdDev(_Symbol, PERIOD_M5, InpPeriod, 0, MODE_SMA, PRICE_CLOSE);
   
   // 1時間足（H1）の移動平均線と標準偏差のハンドルを取得
   handle_ma_h1 = iMA(_Symbol, PERIOD_H1, InpPeriod, 0, MODE_SMA, PRICE_CLOSE);
   handle_std_h1 = iStdDev(_Symbol, PERIOD_H1, InpPeriod, 0, MODE_SMA, PRICE_CLOSE);

   // エラーチェック
   if(handle_ma_m5 == INVALID_HANDLE || handle_std_m5 == INVALID_HANDLE ||
      handle_ma_h1 == INVALID_HANDLE || handle_std_h1 == INVALID_HANDLE)
     {
      Print("エラー：インジケーターのハンドル作成に失敗しました。");
      return(INIT_FAILED);
     }

   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| 毎ティックの計算処理 (OnCalculate)                               |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   // 計算の開始位置を設定（過去のバーを再計算しないための処理）
   int limit = prev_calculated == 0 ? 0 : prev_calculated - 1;

   // 各バーに対してループ処理
   for(int i = limit; i < rates_total; i++)
     {
      datetime t = time[i]; // 現在計算しているバーの時間

      // 一時的に値を格納する配列
      double ma_5m[1], std_5m[1];
      double ma_1h[1], std_1h[1];
      double close_1h[1];

      // 指定した時間のデータを取得
      if(CopyBuffer(handle_ma_m5, 0, t, 1, ma_5m) <= 0) continue;
      if(CopyBuffer(handle_std_m5, 0, t, 1, std_5m) <= 0) continue;
      if(CopyBuffer(handle_ma_h1, 0, t, 1, ma_1h) <= 0) continue;
      if(CopyBuffer(handle_std_h1, 0, t, 1, std_1h) <= 0) continue;
      if(CopyClose(_Symbol, PERIOD_H1, t, 1, close_1h) <= 0) continue;

      // 5分足の波（Zスコア）を計算
      double z_5m = 0;
      if(std_5m[0] > 0) 
         z_5m = (close[i] - ma_5m[0]) / std_5m[0];

      // 1時間足の波（Zスコア）を計算
      double z_1h = 0;
      if(std_1h[0] > 0) 
         z_1h = (close_1h[0] - ma_1h[0]) / std_1h[0];

      // 干渉度（2つの波の積）を計算し、バッファに格納
      InterferenceBuffer[i] = z_5m * z_1h;
     }

   return(rates_total);
  }
//+------------------------------------------------------------------+