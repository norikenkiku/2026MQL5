﻿//+------------------------------------------------------------------+
//|                                         SharpWave_Indicator.mq5  |
//|                                  Copyright 2024, Gemini Physics  |
//+------------------------------------------------------------------+
#property copyright "Gemini"
#property link      "https://www.google.com"
#property version   "1.00"
#property indicator_separate_window
#property indicator_buffers 1
#property indicator_plots   1

// プロットの設定
#property indicator_label1  "Sharpness Ratio (ROC/ATR)"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrCyan
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2

// 入力パラメータ
input int InpROCPeriod = 12; // ROCの期間
input int InpATRPeriod = 14; // ATRの期間

// バッファ
double SharpnessBuffer[];

//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
{
   SetIndexBuffer(0, SharpnessBuffer, INDICATOR_DATA);
   IndicatorSetString(INDICATOR_SHORTNAME, "SharpWave (ROC/ATR)");
   IndicatorSetInteger(INDICATOR_DIGITS, 2);
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   // 計算に必要な最小バー数を確認
   int lookback = MathMax(InpROCPeriod, InpATRPeriod);
   if(rates_total < lookback + 1) return(0);

   int start = prev_calculated - 1;
   if(start < lookback) start = lookback;

   for(int i = start; i < rates_total; i++)
   {
      // 1. ROCの計算 (価格の変化量)
      double roc = close[i] - close[i - InpROCPeriod];
      
      // 2. ATRの計算 (振幅の平均) - 簡易的な算出
      double tr_sum = 0;
      for(int j = 0; j < InpATRPeriod; j++)
      {
         double high_low = high[i-j] - low[i-j];
         double high_close = MathAbs(high[i-j] - close[i-j-1]);
         double low_close = MathAbs(low[i-j] - close[i-j-1]);
         tr_sum += MathMax(high_low, MathMax(high_close, low_close));
      }
      double atr = tr_sum / InpATRPeriod;

      // 3. 鋭さの算出 (不確定性原理的アプローチ)
      // ATRが0の場合の回避策
      if(atr > 0)
         SharpnessBuffer[i] = MathAbs(roc) / atr;
      else
         SharpnessBuffer[i] = 0;
   }

   return(rates_total);
}